ViewerJsImagePlugin
=======

This is a ready-to-go fork of ViewerJs.org (from [kogmbh github repository](https://github.com/kogmbh/ViewerJS), version in [commit 70047e8](https://github.com/kogmbh/ViewerJS/commit/70047e8a7ad268a63fce98fac4ba52a04fd43889)) with the addition of a simple plugin to display images (ImageViewerPlugin.js)
Just open the browser pointing the file index-strae.html#FILEPATH